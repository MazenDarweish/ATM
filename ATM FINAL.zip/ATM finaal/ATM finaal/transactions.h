#pragma once
#ifndef TRANSACTIONS_H
#define TRANSACTIONS_H
#include "user.h"

typedef struct Transaction
{
	int NO_Of_Transaction;
	char Transaction_type;   //deposit or withdraw
	float amount;
	int User_ID;
	struct Transaction* next;
}Transaction;

//functions
void Monitor_Transactions(int User_ID, char transaction_type, float amount);
void Balance_Inquiry(User* user);
void Deposit_Funds(User* user, float Deposit_Amount);
void Withdraw_Funds(User* user, float Withdraw_Amount);
void Transaction_History(int User_ID);
void Free_Spots(struct User* head);
#endif