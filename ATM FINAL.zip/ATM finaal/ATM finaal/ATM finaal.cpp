// ATM finaal.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "user.h"
#include "transactions.h"



int main()
{
	const char* FileName = "users.csv";
	char username[30], password[5];
	int PASSWORD_WRONG = 1, Exit = 1, Continue_Input = 1;
	int Operation, Continue_Program;
	User* Current_User = NULL;

	// load users from the CSV file into a linked list
	struct User* users = LoadUserData(FileName);
	if (users == NULL)
	{
		printf("ERROR loading Data.\n");
		return -1;
	}

	while (Exit)
	{
		printf("Choose\n1: Enter ATM System\n2: Exit ATM System\n");
		scanf("%d", &Continue_Program);
		switch (Continue_Program)
		{
		case 1:
		{
			while (PASSWORD_WRONG)
			{
				printf("Please enter your username: ");
				scanf("%s", username);
				printf("Please enter your PIN number: ");
				scanf("%s", password);
				Current_User = User_Authentication(users, username, password);
				if (Current_User != NULL)
				{
					printf("welcome to the ATM system!\n");
					PASSWORD_WRONG = 0;
				}
				else
				{
					printf("Wrong username or password, please try again..\n");
					PASSWORD_WRONG = 1;
				}
			}
			PASSWORD_WRONG = 1; //to get out the wrong password condition loop
		
			while (Continue_Input)
			{
				printf("Choose\n1: Balance inquiry\n2: Deposit Funds\n3: Withdraw Funds\n4: Transaction history\n5: Exit from Account\n");
				scanf("%d", &Operation);
				switch (Operation)
				{
				case 1:
				{
					Balance_Inquiry(Current_User);
					break;
				}
				case 2:
				{
					float Deposit_Amount;
					printf("Enter amount of Money to deposit: ");
					scanf("%f", &Deposit_Amount);
					Deposit_Funds(Current_User, Deposit_Amount);
					break;
				}
				case 3:
				{
					float Withdraw_Amount;
					printf("Enter amount of Money to withdraw: ");
					scanf("%f", &Withdraw_Amount);
					Withdraw_Funds(Current_User, Withdraw_Amount);
					break;
				}
				case 4:
				{
					Transaction_History(Current_User->User_ID);
					break;
				}
				case 5:
				{
					Continue_Input = 0;
					break;
				}
				default:
				{
					printf("Invalid Input.");
					break;
				}
				}
			}
			break;
		}
		case 2:
		{
			Exit = 0;
			printf("Have A Nice Day.\n");
			break;
		}
		default:
		{
			printf("Invalid Input");
			break;
		}
		}
	}
	Free_Spots(users);
	return 0;
}