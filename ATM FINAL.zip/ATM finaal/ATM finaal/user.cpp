#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "user.h"

// function to register a new user
struct User* RegisterUser(int id, const char* username, const char* password, float balance)
{
	struct User* new_user = (struct User*)malloc(sizeof(struct User));
	if (new_user == NULL)
	{
		printf("ERROR allocationg in memory");
		return NULL;
	}
	new_user->User_ID = id;
	strcpy(new_user->username, username);
	strcpy(new_user->password, password);
	new_user->Account_balance = balance;
	new_user->next = NULL;
	return new_user;
}
// function to load users from the CSV file to the linked list
struct User* LoadUserData(const char* File_name)
{
	FILE* file = fopen(File_name, "r");
	if (!file)
	{
		perror("ERROR Opening file");
		return NULL;
	}
	struct User* head = NULL;
	struct User* tail = NULL;
	char line[100];
    // skip the header 
	fgets(line, sizeof(line), file);
	// read lines in the CSV file
	while (fgets(line, sizeof(line), file))
	{
		line[strcspn(line, "\n")] = 0;
		int id;
		char username[30];
		char password[5];
		float balance;
		//ID, username, password, balance
		if (sscanf(line, "%d,%[^,],%[^,],%f", &id, username, password, &balance))
		{
			// register a place for a new user then add to the linked list
			struct User* new_user = RegisterUser(id, username, password, balance);
			if (head == NULL)
			{
				head = new_user;
				tail = new_user;
			}
			else
			{
				tail->next = new_user;
				tail = new_user;
			}
		}
	}
	fclose(file);
	return head;
}
// function to authenticate a user based on username and password
struct User* User_Authentication(struct User* head, const char* username, const char* password)
{
	struct User* Account = head;
	while (Account != NULL)
	{
		if (strcmp(Account->username, username) == 0 && strcmp(Account->password, password) == 0)
		{
			printf("Authentication successful\n");
			return Account;  
		}
		Account = Account->next;
	}
	printf("Authentication failed\n");
	return NULL;  
}